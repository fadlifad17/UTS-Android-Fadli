package com.example.uts_andro.model;

public class AlumniModel {
    int id;
    String Nim;
    String Nama;
    String TempatLahir;
    String TglLahir;
    String Alamat;
    String Agama;
    String Tlp;
    String Masuk;
    String Lulus;
    String Pekerjaan;
    String Jabatan;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNim() {
        return Nim;
    }

    public void setNim(String nim) {
        Nim = nim;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getTempatLahir() {
        return TempatLahir;
    }

    public void setTempatLahir(String tempatLahir) {
        TempatLahir = tempatLahir;
    }

    public String getTglLahir() {
        return TglLahir;
    }

    public void setTglLahir(String tglLahir) {
        TglLahir = tglLahir;
    }

    public String getAlamat() {
        return Alamat;
    }

    public void setAlamat(String alamat) {
        Alamat = alamat;
    }

    public String getAgama() {
        return Agama;
    }

    public void setAgama(String agama) {
        Agama = agama;
    }

    public String getTlp() {
        return Tlp;
    }

    public void setTlp(String tlp) {
        Tlp = tlp;
    }

    public String getMasuk() {
        return Masuk;
    }

    public void setMasuk(String masuk) {
        Masuk = masuk;
    }

    public String getLulus() {
        return Lulus;
    }

    public void setLulus(String lulus) {
        Lulus = lulus;
    }

    public String getPekerjaan() {
        return Pekerjaan;
    }

    public void setPekerjaan(String pekerjaan) {
        Pekerjaan = pekerjaan;
    }

    public String getJabatan() {
        return Jabatan;
    }

    public void setJabatan(String jabatan) {
        Jabatan = jabatan;
    }
}
